<?php
echo "Funcionando!";
?>
